<script setup lang="js">

</script>

<template>
  <div class="w-full min-h-screen flex flex-col p-8">
    <div class="grid grid-cols-6 items-end w-full justify-center">
      <p class="col-span-1"></p>
      <div class="relative col-span-4 h-102">
        <img
            src="/MainLogo.png"
            class="w-full h-full "
        />
      </div>
      <p class="col-span-1 text-2xl bg-emerald-300 hover:bg-amber-200 text-black hover:text-gray-700 cursor-pointer rounded-xl text-center">Login</p>
    </div>

    <!-- Top row -->
    <div class="grid grid-cols-6 mt-8 border border-white/20 divide-x divide-white/20">
      <div class="col-span-1 p-4 text-center text-2xl">Classes</div>
      <div class="col-span-4 p-4 text-center text-2xl">Booking</div>
      <div class="col-span-1 p-4 text-center text-2xl">Members</div>
    </div>

    <!-- Bottom row -->
    <div class="grid grid-cols-6 flex-1 border border-t-0 border-white/20 divide-x divide-white/20">
      <div class="col-span-1 p-4 text-center">Classes List</div>
      <div class="col-span-4 p-4 text-center">Calendar</div>
      <div class="col-span-1 p-4 text-center"><MemberList /></div>
    </div>
  </div>
</template>

<style scoped>

</style>